const navMenu = document.getElementById('nav-menu'),
      navToggle = document.getElementById('nav-toggle'),
      navClose = document.getElementById('nav-close')

if(navToggle){
    navToggle.addEventListener('click', () =>{
        navMenu.classList.add('show-menu')
    })
}

if(navClose){
    navClose.addEventListener('click', () =>{
        navMenu.classList.remove('show-menu')
    })
}

const navLink = document.querySelectorAll('.nav__link')

const linkAction = () =>{
    const navMenu = document.getElementById('nav-menu')
    navMenu.classList.remove('show-menu')
}
navLink.forEach(n => n.addEventListener('click', linkAction))

const scrollHeader = () =>{
    const header = document.getElementById('header')
    this.scrollY >= 50 ? header.classList.add('scroll-header') 
                       : header.classList.remove('scroll-header')
}
window.addEventListener('scroll', scrollHeader)

let testimonialSwiper = new Swiper(".testimonial-swiper", {
    spaceBetween: 30,
    loop: 'true',

    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});

let newSwiper = new Swiper(".new-swiper", {
    spaceBetween: 24,
    loop: 'true',

    breakpoints: {
        576: {
          slidesPerView: 2,
        },
        768: {
          slidesPerView: 3,
        },
        1024: {
          slidesPerView: 4,
        },
    },
});

const sections = document.querySelectorAll('section[id]')
    



const cart = document.getElementById('cart'),
      cartShop = document.getElementById('cart-shop'),
      cartClose = document.getElementById('cart-close')


if(cartShop){
    cartShop.addEventListener('click', () =>{
        cart.classList.add('show-cart')
    })
}

if(cartClose){
    cartClose.addEventListener('click', () =>{
        cart.classList.remove('show-cart')
    })
}

const themeButton = document.getElementById('theme-button')
const darkTheme = 'dark-theme'
const iconTheme = 'bx-sun'

const selectedTheme = localStorage.getItem('selected-theme')
const selectedIcon = localStorage.getItem('selected-icon')

const getCurrentTheme = () => document.body.classList.contains(darkTheme) ? 'dark' : 'light'
const getCurrentIcon = () => themeButton.classList.contains(iconTheme) ? 'bx bx-moon' : 'bx bx-sun'

if (selectedTheme) {
  document.body.classList[selectedTheme === 'dark' ? 'add' : 'remove'](darkTheme)
  themeButton.classList[selectedIcon === 'bx bx-moon' ? 'add' : 'remove'](iconTheme)
}

themeButton.addEventListener('click', () => {
    document.body.classList.toggle(darkTheme)
    themeButton.classList.toggle(iconTheme)
    localStorage.setItem('selected-theme', getCurrentTheme())
    localStorage.setItem('selected-icon', getCurrentIcon())
})

const addCartBtns = document.querySelectorAll(".products__button");

addCartBtns.forEach(button => {
    button.addEventListener("click", event => {
        const productBox = event.target.closest(".products__card");
        addToCart(productBox);
    });
});

const cartContent = document.querySelector(".cart__container");
const addToCart = productBox => {
    const productImg = productBox.querySelector("img").src;
    const productTitle = productBox.querySelector(".products__title").textContent;
    const productPrice = productBox.querySelector(".products__price").textContent;
    
    const cartItems = cartContent.querySelectorAll(".cart__title");
        for (let item of cartItems) {
        if (item.textContent == productTitle){
            alert("this item is already in the cart.");
            return;
        };
    };


    const cartBox = document.createElement("div");
    cartBox.classList.add("cart__card");
    cartBox.innerHTML = `
        <img src="${productImg}" alt="" class="cart__img">
        <div class="cart__details">
            <h3 class="cart__title">${productTitle}</h3>
            <span class="cart__price">${productPrice}</span>
            <div class="cart__amount">
                <div class="cart__amount-content">
                    <button class="cart__amount-box" id="decrement">-</button>
                    <span class="cart__amount-number">1</span>
                    <button class="cart__amount-box" id="increment">+</button>
                </div>
                <i class='bx bx-trash-alt cart__amount-trash' ></i>
            </div>
        </div>
        `;

        cartContent.appendChild(cartBox);

        cartBox.querySelector(".cart__amount-trash").addEventListener("click", () => {
            cartBox.remove();

            updateCartCount(-1);

            updateTotal();
        });

        cartBox.querySelector(".cart__amount-content").addEventListener("click", event => {
            const numberElement = cartBox.querySelector(".cart__amount-number");
            const decrementButton = cartBox.querySelector("#decrement");
            let quantity = numberElement.textContent

            if (event.target.id === "decrement" && quantity > 1) {
                quantity--;
                if (quantity === 1) {
                    decrementButton.style.color = "#999";
                }        
            }
            else if (event.target.id === "increment") {
                decrementButton.style.color = "#333";
                quantity++;
            }

            numberElement.textContent = quantity;

            updateTotal();
        });

        updateCartCount(1);

        updateTotal();
};

const updateTotal = () => {
    const totalPriceElement = document.querySelector(".cart__prices-total");
    const cartBoxes = cartContent.querySelectorAll(".cart__card");
    let total = 0;
    cartBoxes.forEach(cartBox => {
        const priceElement = cartBox.querySelector(".cart__price");
        const quantityElement = cartBox.querySelector(".cart__amount-number");
        const price = priceElement.textContent.replace("₱", "");
        const quantity = quantityElement.textContent;
        total += price * quantity;
    });
    totalPriceElement.textContent = `₱${total}`
}

let cartItemCount = 0;
const updateCartCount = change => {
    const cartItemCountBadge = document.querySelector(".cart-item-count");
    cartItemCount += change;
    if (cartItemCount > 0) {
        cartItemCountBadge.style.visibility = "visible";
        cartItemCountBadge.textContent = cartItemCount;
    } else {
        cartItemCountBadge.style.visibility = "hidden";
        cartItemCountBadge.textContent = "";

    }
};

const buyNowButton = document.querySelector(".Checkout");
buyNowButton.addEventListener("click", () => {
    const cartBoxes = cartContent.querySelectorAll(".cart__card");
    if (cartBoxes.length === 0) {
        alert("Your cart is empty. Please add items to your cart before buying.");
        return;
    }

    alert("Thank you for your purchase!");


    cartItemCount = 0;
    updateCartCount(0);

    updateTotal();

});

// ===== Checkout → Save Orders to localStorage and Redirect =====
(function () {
  const checkoutBtn = document.getElementById('checkout-btn');
  const cartContent = document.querySelector('.cart__container');

  function parsePrice(str) {
    return parseFloat(str.replace(/[^0-9.]/g, '')) || 0;
  }

  function getNextOrderId() {
    let nextId = parseInt(localStorage.getItem('nextOrderId') || '1001');
    localStorage.setItem('nextOrderId', nextId + 1);
    return nextId;
  }

  // ✅ FIXED VERSION - always collects proper cart data
  function getCartItems() {
    const items = [];
    document.querySelectorAll('.cart__card').forEach(card => {
      const name = card.querySelector('.cart__title')?.textContent.trim() || "Unknown";
      const priceText = card.querySelector('.cart__price')?.textContent.trim() || "₱0";
      const price = parseFloat(priceText.replace(/[^0-9.]/g, "")) || 0;
      const qtyText = card.querySelector('.cart__amount-number')?.textContent.trim() || "1";
      const qty = parseInt(qtyText) || 1;

      items.push({ name, price, qty });
    });
    return items;
  }

  function clearCart() {
    cartContent.innerHTML = '';
  }

  checkoutBtn?.addEventListener('click', e => {
    e.preventDefault();
    const items = getCartItems();
    if (!items.length) {
      alert('Your cart is empty!');
      return;
    }

    const total = items.reduce((sum, item) => sum + item.price * item.qty, 0);
    const order = {
      id: getNextOrderId(),
      items: items,
      total: parseFloat(total.toFixed(2)),
      date: new Date().toISOString(),
      status: 'Processing'
    };

    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    orders.unshift(order);
    localStorage.setItem('orders', JSON.stringify(orders));

    clearCart();
    updateTotal()
  });
})();

(function () {
  const checkoutBtn = document.getElementById("checkout-btn");
  const cartContent = document.querySelector(".cart__container");

  function getNextOrderId() {
    let nextId = parseInt(localStorage.getItem("nextOrderId") || "1001");
    localStorage.setItem("nextOrderId", nextId + 1);
    return nextId;
  }

  function getCartItems() {
    const items = [];
    document.querySelectorAll(".cart__card").forEach(card => {
      const name = card.querySelector(".cart__title")?.textContent.trim();
      const price = parseFloat(card.querySelector(".cart__price").textContent.replace(/[^0-9.]/g, ""));
      const qty = parseInt(card.querySelector(".cart__amount-number").textContent.trim()) || 1;
      items.push({ name, price, qty });
    });
    return items;
  }

  function updateStocksAfterCheckout(items) {
    let stocks = JSON.parse(localStorage.getItem("stocks")) || [];
    items.forEach(orderItem => {
      const stockItem = stocks.find(s => s.name === orderItem.name);
      if (stockItem) {
        stockItem.stock = Math.max(0, stockItem.stock - orderItem.qty);
      }
    });
    localStorage.setItem("stocks", JSON.stringify(stocks));
  }

  function clearCart() {
    cartContent.innerHTML = "";
  }

  checkoutBtn?.addEventListener("click", e => {
    e.preventDefault();
    const items = getCartItems();
    if (!items.length) {
      alert("Your cart is empty!");
      return;
    }

    const total = items.reduce((sum, item) => sum + item.price * item.qty, 0);
    const order = {
      id: getNextOrderId(),
      items: items,
      total: parseFloat(total.toFixed(2)),
      date: new Date().toISOString(),
      status: "Processing"
    };

    const orders = JSON.parse(localStorage.getItem("orders") || "[]");
    orders.unshift(order);
    localStorage.setItem("orders", JSON.stringify(orders));

    updateStocksAfterCheckout(items); // 🔥 Deduct stock here
    clearCart();
    alert("Order placed successfully!");
    window.location.href = "orderhistory.html";
  });
})();






