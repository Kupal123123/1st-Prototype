<?php
$host = "localhost";
$user = "root";     // your phpMyAdmin username
$pass = "";         // your phpMyAdmin password
$db   = "lagro_bistro";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
