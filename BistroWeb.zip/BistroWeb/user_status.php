<?php
include 'db_connect.php';
$id = $_POST['id'];
$action = $_POST['action'];
$status = $action === "ban" ? "banned" : "active";

$query = "UPDATE users SET status='$status' WHERE id='$id'";
if (mysqli_query($conn, $query)) {
  echo json_encode(["success" => true, "message" => "User status updated to $status."]);
} else {
  echo json_encode(["success" => false, "message" => "Error: " . mysqli_error($conn)]);
}
?>
