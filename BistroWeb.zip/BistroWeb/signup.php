<?php
include 'db_connect.php';
session_start();

// When form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = trim($_POST['username']);
  $password = trim($_POST['password']);
  $confirm  = trim($_POST['confirm']);
  $lrn      = trim($_POST['lrn']);
  $grade    = trim($_POST['grade']);
  $section  = trim($_POST['section']);

  // Basic validation
  if (empty($username) || empty($password) || empty($confirm) || empty($lrn) || empty($grade) || empty($section)) {
    $error = "All fields are required.";
  } elseif ($password !== $confirm) {
    $error = "Passwords do not match.";
  } else {
    // Check if username already exists
    $check = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    if (mysqli_num_rows($check) > 0) {
      $error = "Username already exists. Please choose another.";
    } else {
      // Encrypt password (still MD5 for now)
      $hash = md5($password);

      // Insert new user (with LRN, Grade, Section)
      $sql = "INSERT INTO users (username, password, role, lrn, grade, section) 
              VALUES ('$username', '$hash', 'customer', '$lrn', '$grade', '$section')";

      if (mysqli_query($conn, $sql)) {
        echo "<script>
                alert('Account created successfully! You can now log in.');
                window.location.href='login.html';
              </script>";
        exit;
      } else {
        $error = 'Error creating account: ' . mysqli_error($conn);
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">
  <title>Sign Up | Lagro Bistro</title>
</head>
<body>

<header class="header" id="header">
  <nav class="nav container">
    <a href="index.php" class="nav__logo">
      <img src="photos/487406000_1540026813360052_5463353511999549857_n (1).png" class="logo" alt="">
      Lagro Bistro
    </a>
    <div class="nav__menu" id="nav-menu">
      <ul class="nav__list">
        <li class="nav__item"><a href="index.php" class="nav__link">Home</a></li>
        <li class="nav__item"><a href="login.html" class="nav__link">Login</a></li>
      </ul>
      <div class="nav__close" id="nav-close"><i class='bx bx-x'></i></div>
    </div>
    <div class="nav__btns">
      <i class='bx bx-moon change-theme' id="theme-button"></i>
      <div class="nav__toggle" id="nav-toggle"><i class='bx bx-grid-alt'></i></div>
    </div>
  </nav>
</header>

<main class="main" style="margin-top:6rem;">
  <section class="section container" style="max-width:400px; margin:auto; text-align:center;">
    <h2 class="section__title">Create an Account</h2>
    <p style="margin-bottom:1.5rem; color:var(--text-color-light);">Join Lagro Bistro to place and track your orders.</p>

    <?php if (isset($error)): ?>
      <div style="color:red; font-size:.9rem; margin-bottom:1rem;"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="signup.php" method="POST" class="grid" style="row-gap:1.25rem;">
      <div class="form__group">
        <label for="username" style="display:block; text-align:left; margin-bottom:.5rem;">Username</label>
        <input type="text" name="username" id="username" placeholder="Enter a username" required
          style="width:100%; padding:.75rem; border:1px solid var(--border-color); border-radius:.5rem;">
      </div>

      <div class="form__group">
        <label for="password" style="display:block; text-align:left; margin-bottom:.5rem;">Password</label>
        <input type="password" name="password" id="password" placeholder="Enter a password" required
          style="width:100%; padding:.75rem; border:1px solid var(--border-color); border-radius:.5rem;">
      </div>

      <div class="form__group">
        <label for="confirm" style="display:block; text-align:left; margin-bottom:.5rem;">Confirm Password</label>
        <input type="password" name="confirm" id="confirm" placeholder="Re-enter password" required
          style="width:100%; padding:.75rem; border:1px solid var(--border-color); border-radius:.5rem;">
      </div>

      <!-- ✅ New Fields -->
      <div class="form__group">
        <label for="lrn" style="display:block; text-align:left; margin-bottom:.5rem;">LRN</label>
        <input type="text" name="lrn" id="lrn" placeholder="Enter your LRN" required
          style="width:100%; padding:.75rem; border:1px solid var(--border-color); border-radius:.5rem;">
      </div>

      <div class="form__group">
        <label for="grade" style="display:block; text-align:left; margin-bottom:.5rem;">Grade</label>
        <input type="text" name="grade" id="grade" placeholder="Enter your grade" required
          style="width:100%; padding:.75rem; border:1px solid var(--border-color); border-radius:.5rem;">
      </div>

      <div class="form__group">
        <label for="section" style="display:block; text-align:left; margin-bottom:.5rem;">Section</label>
        <input type="text" name="section" id="section" placeholder="Enter your section" required
          style="width:100%; padding:.75rem; border:1px solid var(--border-color); border-radius:.5rem;">
      </div>

      <button type="submit" class="button" style="width:100%; padding:.75rem;">Sign Up</button>
    </form>

    <p style="margin-top:1rem; font-size:.9rem;">
      Already have an account? <a href="login.html" style="color:var(--first-color); text-decoration:underline;">Login here</a>
    </p>
  </section>
</main>

<footer class="footer section">
  <div class="container" style="text-align:center; padding:1rem 0;">
    <p style="color:var(--text-color-light); font-size:.9rem;">&copy; 2025 Lagro Bistro. All rights reserved.</p>
  </div>
</footer>

<script src="assets/js/swiper-bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
