<?php
session_start();
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data safely
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = md5($_POST['password']); // Note: MD5 is outdated, recommend password_hash later
    $lrn = mysqli_real_escape_string($conn, $_POST['lrn']);
    $grade = mysqli_real_escape_string($conn, $_POST['grade']);
    $section = mysqli_real_escape_string($conn, $_POST['section']);

    // Check if the user exists
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);

        // Store all user info in session
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['lrn'] = $lrn;
        $_SESSION['grade'] = $grade;
        $_SESSION['section'] = $section;

        // Optional: Save LRN, Grade, and Section to the database if they exist in your table
        $update = "UPDATE users 
                   SET lrn='$lrn', grade='$grade', section='$section' 
                   WHERE username='$username'";
        mysqli_query($conn, $update);

        // Redirect based on role
        if ($user['role'] === 'admin') {
            header("Location: stocks.php");
        } else {
            header("Location: index.php");
        }
        exit;
    } else {
        echo "<script>
                alert('Invalid username or password');
                window.location.href='login.html';
              </script>";
    }
}
?>
