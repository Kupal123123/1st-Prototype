<?php
session_start();
include 'db_connect.php';
header("Content-Type: application/json");

// ✅ Check login
if (!isset($_SESSION['username'])) {
    echo json_encode(["success" => false, "error" => "Not logged in"]);
    exit;
}

// ✅ Read JSON input
session_start();
include 'db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
  http_response_code(403);
  echo json_encode(['success' => false, 'error' => 'Not logged in']);
  exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (!$data || empty($data['items'])) {
  echo json_encode(['success' => false, 'error' => 'Invalid order data']);
  exit;
}

$username = $_SESSION['username'];
$items = json_encode($data['items'], JSON_UNESCAPED_UNICODE);
$total = $data['total'];
$payment = $data['payment_method'];
$notes = $data['notes'] ?? '';
$status = 'Processing';

$stmt = $conn->prepare("
  INSERT INTO orders (username, items, total, payment_method, notes, status)
  VALUES (?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
  "ssdsss",
  $username,
  $items,
  $total,
  $payment,
  $notes,
  $status
);

if ($stmt->execute()) {
  echo json_encode(['success' => true]);
} else {
  echo json_encode(['success' => false, 'error' => $stmt->error]);
}
?>
