<?php
include 'db_connect.php';
$id = $_POST['id'];
$username = $_POST['username'];
$lrn = $_POST['lrn'];
$grade = $_POST['grade'];
$section = $_POST['section'];
$role = $_POST['role'];

$query = "UPDATE users SET username='$username', lrn='$lrn', grade='$grade', section='$section', role='$role' WHERE id='$id'";
if (mysqli_query($conn, $query)) {
  echo json_encode(["success" => true, "message" => "User updated successfully."]);
} else {
  echo json_encode(["success" => false, "message" => "Error: " . mysqli_error($conn)]);
}
?>
