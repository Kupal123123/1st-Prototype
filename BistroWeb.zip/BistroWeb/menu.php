<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['username'])) {
  header("Location: login.html");
  exit();
}

// 🛑 Check if user is banned
$username = $_SESSION['username'];
$check = mysqli_query($conn, "SELECT status FROM users WHERE username='$username'");
$user = mysqli_fetch_assoc($check);

if (isset($user['status']) && strtolower($user['status']) === 'banned') {
  session_destroy();
  echo "<script>
          alert('Your account has been banned. Please contact the administrator.');
          window.location.href='login.html';
        </script>";
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Menu | Lagro Bistro</title>

  <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">

  <style>
    .menu__search {
      display: flex;
      justify-content: center;
      margin-bottom: 2rem;
    }
    .menu__search input {
      width: 80%;
      max-width: 400px;
      padding: 0.6rem 1rem;
      border: 1px solid var(--border-color);
      border-radius: 0.5rem;
      font-size: 1rem;
      outline: none;
    }
    .category__title {
      margin: 2rem 0 1rem;
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--title-color);
    }
    header {
  background-color: var(--body-color);
  box-shadow: 0 1px 4px hsla(0, 4%, 15%, .10);
}
    #theme{
      white
    }
    #bag {
      white
    }
  </style>
</head>

<body>
<header class="header" id="header">
  <nav class="nav container">
    <a href="index.php" class="nav__logo">
      <img src="photos/487406000_1540026813360052_5463353511999549857_n (1).png" class="logo" alt="">
      Lagro Bistro
    </a>

    <div class="nav__menu" id="nav-menu">
      <ul class="nav__list">
        <li class="nav__item"><a href="index.php" class="nav__link">Home</a></li>
        <li class="nav__item"><a href="menu.php" class="nav__link active-link">Menu</a></li>
        <li class="nav__item"><a href="orderhistory.php" class="nav__link">Order History</a></li>
        <?php if ($_SESSION['role'] === 'admin'): ?>
          <li class="nav__item"><a href="stocks.php" class="nav__link">Stocks</a></li>
        <?php endif; ?>
        <li class="nav__item"><a href="logout.php" class="nav__link">Logout</a></li>
      </ul>
      <div class="nav__close" id="nav-close"><i class='bx bx-x'></i></div>
    </div>

    <div class="nav__btns">
      <i id='theme' class='bx bx-moon change-theme' id="theme-button"></i>
      <div class="nav__shop" id="cart-button"><i id='bag' class='bx bx-shopping-bag'></i></div>
      <div class="nav__toggle" id="nav-toggle"><i class='bx bx-grid-alt'></i></div>
    </div>
  </nav>
</header>

<div class="cart" id="cart">
  <i class='bx bx-x cart__close' id="cart-close"></i>
  <h2 class="cart__title-center">My Cart</h2>
  <div class="cart__container"></div>
  <div class="cart__prices">
    <span class="cart__prices-item">Total</span>
    <span class="cart__prices-total">₱0</span>
  </div>
  <div align="center">
    <button id="checkout-btn" class="Checkout">Check out</button>
  </div>
</div>

<main class="main" style="margin-top:5rem;">
  <section class="menu section container">
    <h2 class="section__title">Our Menu</h2>
    <div class="menu__search">
      <input type="text" id="searchInput" placeholder="Search for an item...">
    </div>
    <div id="menu-content"></div>
  </section>
</main>

<footer class="footer section">
  <div class="container" style="text-align:center; padding:1rem 0;">
    <p style="color:var(--text-color-light); font-size:.9rem;">&copy; 2025 Lagro Bistro. All rights reserved.</p>
  </div>
</footer>

<a href="#" class="scrollup" id="scroll-up"><i class='bx bx-up-arrow-alt scrollup__icon'></i></a>

<script src="assets/js/swiper-bundle.min.js"></script>
<script src="assets/js/main.js"></script>

<script>

document.addEventListener("DOMContentLoaded", () => {
  const menuContent = document.getElementById("menu-content");
  const searchInput = document.getElementById("searchInput");
  const cartContainer = document.querySelector(".cart__container");
  const totalDisplay = document.querySelector(".cart__prices-total");
  const checkoutBtn = document.getElementById("checkout-btn");
  const cartBtn = document.getElementById("cart-button");
  const cart = document.getElementById("cart");
  const cartClose = document.getElementById("cart-close");

  cartBtn?.addEventListener("click", () => cart.classList.add("show-cart"));
  cartClose?.addEventListener("click", () => cart.classList.remove("show-cart"));

  function loadStocks() {
    try {
      const raw = localStorage.getItem("stocks");
      const arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr : [];
    } catch {
      return [];
    }
  }

  function groupByCategory(items) {
    const groups = {};
    items.forEach(item => {
      const cat = item.category || "Uncategorized";
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(item);
    });
    return groups;
  }

  function renderMenu(filter = "") {
    const stocks = loadStocks();
    const grouped = groupByCategory(stocks);
    menuContent.innerHTML = "";

    Object.keys(grouped).forEach(category => {
      const filtered = grouped[category].filter(p =>
        p.name.toLowerCase().includes(filter.toLowerCase())
      );
      if (!filtered.length) return;

      const section = document.createElement("div");
      section.innerHTML = `
        <h3 class="category__title">${category}</h3>
        <div class="products__container grid"></div>
      `;
      const grid = section.querySelector(".products__container");

      filtered.forEach(product => {
        const disabled = product.qty <= 0 ? "disabled" : "";
        const stockStatus = product.qty <= 0
          ? `<span class='out-of-stock'>Out of Stock</span>`
          : product.qty <= 3
          ? `<span class='low-stock'>Low Stock</span>`
          : `<span class='in-stock'>In Stock</span>`;

        grid.insertAdjacentHTML("beforeend", `
          <article class="products__card" data-id="${product.id}">
            <img src="${product.image}" alt="${product.name}" class="products__img">
            <h3 class="products__title">${product.name}</h3>
            <span class="products__price">₱${product.price}</span>
            <p class="stock-label">${stockStatus} — ${product.qty} left</p>
            <button class="products__button" data-id="${product.id}" ${disabled}>
              ${disabled ? "Out of Stock" : "Add to Cart"}
            </button>
          </article>
        `);
      });

      menuContent.appendChild(section);
    });
  }

  let cartData = JSON.parse(localStorage.getItem("cart") || "[]");
  function saveCart() { localStorage.setItem("cart", JSON.stringify(cartData)); }

  function renderCart() {
    cartContainer.innerHTML = "";
    let total = 0;
    cartData.forEach((item, i) => {
      total += item.price * item.qty;
      cartContainer.insertAdjacentHTML("beforeend", `
        <div class="cart__card">
          <img src="${item.image}" class="cart__img">
          <div class="cart__details">
            <h3 class="cart__title">${item.name}</h3>
            <span class="cart__price">₱${item.price}</span>
            <div class="cart__amount">
              <div class="cart__amount-content">
                <button class="cart__amount-box cart-decr" data-index="${i}">-</button>
                <span class="cart__amount-number">${item.qty}</span>
                <button class="cart__amount-box cart-incr" data-index="${i}">+</button>
              </div>
              <i class='bx bx-trash-alt cart__amount-trash' data-index="${i}"></i>
            </div>
          </div>
        </div>
      `);
    });
    totalDisplay.textContent = "₱" + total.toFixed(2);
  }

  menuContent.addEventListener("click", (e) => {
    const btn = e.target.closest(".products__button");
    if (!btn) return;
    const id = btn.dataset.id;
    const stocks = loadStocks();
    const product = stocks.find(p => String(p.id) === id);
    if (!product || product.qty <= 0) return alert("Out of stock.");

    const existing = cartData.find(c => String(c.id) === id);
    if (existing) existing.qty += 1;
    else cartData.push({ id: product.id, name: product.name, price: product.price, qty: 1, image: product.image });

    product.qty = Math.max(0, product.qty - 1);
    localStorage.setItem("stocks", JSON.stringify(stocks));

    saveCart();
    renderCart();
    renderMenu(searchInput.value);
  });

  cartContainer.addEventListener("click", (e) => {
    const idx = e.target.dataset.index;
    const stocks = loadStocks();
    const item = cartData[idx];
    const stock = stocks.find(p => p.id === item.id);

    if (e.target.classList.contains("cart-incr")) {
      if (stock && stock.qty > 0) {
        item.qty += 1;
        stock.qty -= 1;
      } else return alert("No more stock available.");
    }

    if (e.target.classList.contains("cart-decr")) {
      if (item.qty > 1) {
        item.qty -= 1;
        if (stock) stock.qty += 1;
      }
    }

    if (e.target.classList.contains("cart__amount-trash")) {
      if (stock) stock.qty += item.qty;
      cartData.splice(idx, 1);
    }

    localStorage.setItem("stocks", JSON.stringify(stocks));
    saveCart();
    renderCart();
    renderMenu(searchInput.value);
  });

  // ✅ FIXED CHECKOUT
  checkoutBtn.addEventListener("click", async () => {
    if (!cartData.length) return alert("Your cart is empty!");

    const orderItems = cartData.map(c => ({
      name: c.name,
      qty: c.qty,
      price: c.price
    }));

    const total = cartData.reduce((s, i) => s + i.price * i.qty, 0);

    try {
      const response = await fetch("save_order.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: orderItems, total })
      });

      const result = await response.json();

      if (result.success) {
        alert("✅ Order placed successfully!");
        cartData = [];
        saveCart();
        renderCart();
        window.location.href = "orderhistory.php";
      } else {
        alert("❌ Failed to save order: " + (result.error || "Unknown error"));
      }
    } catch (err) {
      alert("⚠️ Could not connect to the server: " + err.message);
    }
  });

  searchInput.addEventListener("input", e => renderMenu(e.target.value));
  renderMenu();
  renderCart();
});
</script>

<style>
  .out-of-stock { color: #f87171; font-weight: 600; }
  .low-stock { color: #facc15; font-weight: 600; }
  .in-stock { color: #4ade80; font-weight: 600; }
  .stock-label { margin-top: 5px; font-size: 0.9rem; }
</style>
</body>
</html>
