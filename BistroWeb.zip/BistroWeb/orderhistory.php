<?php
session_start();
include 'db_connect.php';

// Basic login protection
if (!isset($_SESSION['username'])) {
  header("Location: login.html");
  exit();
}

// 🛑 Check if user is banned
$username = $_SESSION['username'];
$check = mysqli_query($conn, "SELECT status FROM users WHERE username='$username'");
$user = mysqli_fetch_assoc($check);

if (isset($user['status']) && strtolower($user['status']) === 'banned') {
  session_destroy();
  echo "<script>
          alert('Your account has been banned. Please contact the administrator.');
          window.location.href='login.html';
        </script>";
  exit();
}

$user = $_SESSION['username'];
$role = $_SESSION['role'] ?? 'user';

// Fetch orders
if ($role === 'admin') {
  $sql = "SELECT * FROM orders ORDER BY created_at DESC";
} else {
  $sql = "SELECT * FROM orders WHERE username = ? ORDER BY created_at DESC";
}
$stmt = $conn->prepare($sql);
if ($role !== 'admin') $stmt->bind_param("s", $user);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Order History | Lagro Bistro</title>

  <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">

  <style>
    .nav { background-color: var(--body-color); }
    .orders-card { background: var(--container-color); border:1px solid var(--border-color); padding:1rem; border-radius:.75rem; box-shadow:0 8px 20px rgba(0,0,0,.04); }
    .orders-table { width:100%; border-collapse: collapse; }
    .orders-table th, .orders-table td { padding:.65rem .5rem; border-bottom:1px solid var(--border-color); font-size:.95rem; text-align:left; vertical-align:middle; }
    .orders-table th { color: var(--text-color-light); font-size:.82rem; text-transform: uppercase; }
    .status-chip { padding:.25rem .6rem; border-radius:.5rem; font-weight:600; font-size:.85rem; display:inline-block; }
    .status-completed { background:#dff5e6; color:#117a2b; }
    .status-processing { background:#fff7d9; color:#b36b00; }
    .status-cancelled { background:#ffecec; color:#a30b0b; }
    .btn-action { margin-right:.5rem; padding:.4rem .7rem; border:none; border-radius:.4rem; cursor:pointer; font-size:.85rem; }
    .btn-finish { background:#16a34a; color:#fff; }
    .btn-cancel { background:#dc2626; color:#fff; }
    .btn-view { background:transparent; border:1px solid var(--border-color); }
    .empty-state { text-align:center; color:var(--text-color-light); padding:2rem 0; }

    #modal-root { display:none; position:fixed; inset:0; align-items:center; justify-content:center; z-index:2000; }
    #modal-root .modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,.45); display:flex; align-items:center; justify-content:center; padding:1rem; }
    #modal-root .modal { width:100%; max-width:700px; background:var(--container-color); padding:1rem; border-radius:.75rem; box-shadow:0 20px 40px rgba(0,0,0,.15); }
    #modal-root h4 { margin-top:.5rem; }
  </style>
</head>
<body>

<!--=============== HEADER ===============-->
<header class="header" id="header">
  <nav class="nav container">
    <a href="index.php" class="nav__logo">
      <img src="photos/487406000_1540026813360052_5463353511999549857_n (1).png" class="logo" alt="">
      Lagro Bistro
    </a>

    <div class="nav__menu" id="nav-menu">
      <ul class="nav__list">
        <li class="nav__item"><a href="index.php" class="nav__link">Home</a></li>
        <li class="nav__item"><a href="menu.php" class="nav__link">Menu</a></li>
        <li class="nav__item"><a href="orderhistory.php" class="nav__link active-link">Order History</a></li>
        <?php if ($role === 'admin'): ?>
          <li class="nav__item"><a href="stocks.php" class="nav__link">Stocks</a></li>
        <?php endif; ?>
        <li class="nav__item"><a href="logout.php" class="nav__link">Logout</a></li>
      </ul>
      <div class="nav__close" id="nav-close"><i class='bx bx-x'></i></div>
    </div>

    <div class="nav__btns">
      <i class='bx bx-moon change-theme' id="theme-button"></i>
      <div class="nav__toggle" id="nav-toggle"><i class='bx bx-grid-alt'></i></div>
    </div>
  </nav>
</header>

<!--=============== MAIN ===============-->
<main class="main" style="margin-top:5.5rem; padding-bottom:4rem;">
  <section class="section container">
    <div class="section__title" style="text-align:center;">Order History</div>

    <div class="orders-card" style="margin-top:1rem;">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:1rem; flex-wrap:wrap;">
        <h3 style="margin:0;">Your Orders</h3>
        <span style="color:var(--text-color-light); font-size:.95rem;">
          <?= $role === 'admin' ? 'All Customer Orders' : 'Orders placed from your account' ?>
        </span>
      </div>

      <div style="overflow:auto; margin-top:.75rem;">
        <table class="orders-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <?php if ($role === 'admin') echo "<th>User</th>"; ?>
              <th>Products</th>
              <th>Date</th>
              <th>Total</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result->num_rows > 0): ?>
              <?php while ($row = $result->fetch_assoc()): ?>
                <?php
                  $items = json_decode($row['items'], true);
                  if (!is_array($items)) $items = [];
                  $summary = '';
                  foreach ($items as $it) {
                    $summary .= htmlspecialchars($it['name']) . ' x' . htmlspecialchars($it['qty']) . ', ';
                  }

                  $summary = rtrim($summary, ', ');
                  $statusClass = match ($row['status']) {
                    'Completed' => 'status-chip status-completed',
                    'Cancelled' => 'status-chip status-cancelled',
                    default => 'status-chip status-processing',
                  };
                ?>
                <tr data-id="<?= $row['id'] ?>">
                  <td>#<?= htmlspecialchars($row['id']) ?></td>
                  <?php if ($role === 'admin') echo "<td>" . htmlspecialchars($row['username']) . "</td>"; ?>
                  <td><?= $summary ?></td>
                  <td><?= htmlspecialchars($row['created_at']) ?></td>
                  <td>₱<?= number_format($row['total'], 2) ?></td>
                  <td><span class="<?= $statusClass ?>"><?= htmlspecialchars($row['status']) ?></span></td>
                  <td>
<button class="btn-action btn-view"
  data-items='<?= htmlspecialchars(json_encode($items), ENT_QUOTES, "UTF-8") ?>'
  data-total="<?= htmlspecialchars($row['total']) ?>"
  data-status="<?= htmlspecialchars($row['status']) ?>"
  data-payment="<?= htmlspecialchars($row['payment_method']) ?>"
  data-notes="<?= htmlspecialchars($row['notes'] ?? '') ?>"
  data-id="<?= $row['id'] ?>">
  <i class='bx bx-show'></i> View
</button>
                    <?php if ($role === 'admin' && $row['status'] === 'Processing'): ?>
                      <button class="btn-action btn-finish" data-status="Completed">Finish</button>
                      <button class="btn-action btn-cancel" data-status="Cancelled">Cancel</button>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="<?= $role === 'admin' ? 7 : 6 ?>"><div class="empty-state">No orders found.</div></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
</main>

<!--=============== MODAL ===============-->
<div id="modal-root">
  <div class="modal-overlay" id="modal-overlay" role="dialog" aria-modal="true">
    <div class="modal" role="document" aria-labelledby="modal-title">
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <h3 id="modal-title">Order Details</h3>
        <button id="modal-close" class="button" style="background:transparent; border:1px solid var(--border-color);">Close</button>
      </div>
      <div id="modal-body" style="margin-top:.5rem;"></div>
    </div>
  </div>
</div>

<!--=============== FOOTER ===============-->
<footer class="footer section">
  <div class="container" style="text-align:center; padding:1rem 0;">
    <p style="color:var(--text-color-light); font-size:.9rem;">&copy; 2025 Lagro Bistro. All rights reserved.</p>
  </div>
</footer>

<script>
document.addEventListener("click", async (e) => {
  const modalRoot = document.getElementById("modal-root");
  const modalBody = document.getElementById("modal-body");
  const overlay = document.getElementById("modal-overlay");
  const closeBtn = document.getElementById("modal-close");

  // View button
if (e.target.closest(".btn-view")) {
  const btn = e.target.closest(".btn-view");

  let items = [];
  try {
    items = JSON.parse(btn.dataset.items || "[]");
  } catch {
    alert("Failed to load order items.");
    return;
  }

  const total = btn.dataset.total;
  const status = btn.dataset.status;
  const payment = btn.dataset.payment || "—";
  const notes = btn.dataset.notes || "";
  const id = btn.dataset.id;

  let html = `
    <p><strong>Order ID:</strong> #${id}</p>
    <p><strong>Status:</strong> ${status}</p>
    <p><strong>Payment Method:</strong> ${payment}</p>
    <p><strong>Total:</strong> ₱${Number(total).toFixed(2)}</p>
  `;

  if (notes.trim() !== "") {
    html += `
      <div class="order-notes">
        <strong>Customer Notes:</strong><br>
        ${notes.replace(/\n/g, "<br>")}
      </div>
    `;
  }

  html += `<h4>Items:</h4><ul>`;
  items.forEach(it => {
    html += `<li>${it.name} × ${it.qty} — ₱${Number(it.price).toFixed(2)}</li>`;
  });
  html += `</ul>`;

  modalBody.innerHTML = html;
  modalRoot.style.display = "flex";
}


  // Close modal
  if (e.target === overlay || e.target === closeBtn) {
    modalRoot.style.display = "none";
  }

  // Admin: Finish/Cancel buttons
  if (e.target.matches(".btn-finish") || e.target.matches(".btn-cancel")) {
    const btn = e.target;
    const tr = btn.closest("tr");
    const id = tr.dataset.id;
    const status = btn.dataset.status;

    if (!confirm(`Mark order #${id} as ${status}?`)) return;

    try {
      const res = await fetch("update_order_status.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: `id=${id}&status=${encodeURIComponent(status)}`
      });
      const data = await res.json();
      if (data.success) {
        alert("Status updated successfully!");
        location.reload();
      } else {
        alert("Error: " + (data.error || "Unknown error"));
      }
    } catch (err) {
      alert("Failed: " + err.message);
    }
  }
});
</script>

<script src="assets/js/swiper-bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
