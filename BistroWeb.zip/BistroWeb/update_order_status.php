<?php
session_start();
include 'db_connect.php';

header("Content-Type: application/json");

// ✅ Check login
if (!isset($_SESSION['username'])) {
  http_response_code(403);
  echo json_encode(["error" => "Not logged in"]);
  exit;
}

// ✅ Check admin role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  http_response_code(403);
  echo json_encode(["error" => "Unauthorized access"]);
  exit;
}

// ✅ Ensure POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(["error" => "Invalid request method"]);
  exit;
}

// ✅ Try to read JSON or form data
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

// If JSON not found, fall back to normal POST
if (!$data) {
  $data = $_POST;
}

// ✅ Validate input
if (!isset($data['id']) || !isset($data['status'])) {
  echo json_encode(["error" => "Invalid input data"]);
  exit;
}

$orderId = intval($data['id']);
$status = trim($data['status']);

// ✅ Check status
$validStatuses = ['Processing', 'Completed', 'Cancelled'];
if (!in_array($status, $validStatuses)) {
  echo json_encode(["error" => "Invalid status value"]);
  exit;
}

// ✅ Update order
$stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
$stmt->bind_param("si", $status, $orderId);

if ($stmt->execute()) {
  echo json_encode(["success" => true, "message" => "Order status updated successfully"]);
} else {
  echo json_encode(["error" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
