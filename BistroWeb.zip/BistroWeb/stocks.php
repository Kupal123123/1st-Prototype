<?php
session_start();
if (!isset($_SESSION['username'])) {
  header("Location: login.html");
  exit();
}
if ($_SESSION['role'] !== 'admin') {
  echo "<script>
          alert('Access denied! Admins only.');
          window.location.href='index.php';
        </script>";
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">
  <title>Stocks | Lagro Bistro</title>

  <style>
    .stocks-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.25rem;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .stocks-card {
      background: var(--container-color);
      border: 1px solid var(--border-color);
      padding: 1rem;
      border-radius: .75rem;
      box-shadow: 0 6px 18px rgba(0,0,0,0.03);
    }
    .stocks-table {
      width: 100%;
      border-collapse: collapse;
      overflow-x: auto;
    }
    .stocks-table th, .stocks-table td {
      padding: .75rem .5rem;
      text-align: left;
      border-bottom: 1px solid var(--border-color);
      vertical-align: middle;
      font-size: .95rem;
    }
    .stocks-table th { text-transform: uppercase; font-size: .8rem; color: var(--text-color-light); }
    .status-badge { padding: .25rem .6rem; border-radius: .5rem; font-size: .8rem; font-weight: 600; display:inline-block; }
    .status-in { background: #dff5e6; color: #117a2b; }
    .status-low { background: #fff7d9; color: #b36b00; }
    .status-out { background: #ffecec; color: #a30b0b; }
    .action-btn { margin-right: .5rem; }
    .modal-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,.45); display:flex; align-items:center; justify-content:center;
      z-index: 2000;
    }
    .modal {
      width: 100%; max-width: 520px; background: var(--container-color); padding: 1.25rem; border-radius: .75rem;
      box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    }
    .form-row { display:flex; gap:.75rem; }
    .form-row .col { flex:1; }
    @media (max-width:600px){
      .form-row { flex-direction: column; }
    }
    .danger-btn {
      background: #a30b0b;
      color: #fff;
      border: none;
      padding: .6rem 1rem;
      border-radius: .5rem;
      cursor: pointer;
    }
    .danger-btn:hover {
      opacity: .9;
    }
  </style>
</head>
<body>
<header class="header" id="header">
  <nav class="nav container">
    <a href="index.php" class="nav__logo">
      <img src="photos/487406000_1540026813360052_5463353511999549857_n (1).png" class="logo" alt="">
      Lagro Bistro
    </a>
    <div class="nav__menu" id="nav-menu">
      <ul class="nav__list">
        <li class="nav__item"><a href="index.php" class="nav__link">Home</a></li>
        <li class="nav__item"><a href="menu.php" class="nav__link">Menu</a></li>
        <li class="nav__item"><a href="orderhistory.php" class="nav__link">Order History</a></li>
        <li class="nav__item"><a href="stocks.php" class="nav__link active-link">Stocks</a></li>
        <li class="nav__item"><a href="logout.php" class="nav__link">Logout</a></li>
      </ul>
      <div class="nav__close" id="nav-close"><i class='bx bx-x'></i></div>
    </div>
    <div class="nav__btns">
      <i class='bx bx-moon change-theme' id="theme-button"></i>
      <div class="nav__toggle" id="nav-toggle"><i class='bx bx-grid-alt'></i></div>
    </div>
  </nav>
</header>

<main class="main" style="margin-top:5.5rem; padding-bottom:4rem;">
  <section class="section container">
    <div class="section__title" style="text-align:center; margin-bottom:1rem;">Inventory / Stocks</div>

    <div class="stocks-card">
      <div class="stocks-header">
        <div style="display:flex; align-items:center; gap:.75rem;">
          <h3 style="margin:0;">Products</h3>
          <span style="color:var(--text-color-light); font-size:.95rem;">Manage product inventory</span>
        </div>
        <div style="display:flex; gap:.5rem; align-items:center;">
          <input id="search-input" type="search" placeholder="Search product..." style="padding:.5rem .75rem; border:1px solid var(--border-color); border-radius:.5rem;">
          <button id="add-item-btn" class="button">+ Add Item</button>
          <button id="clear-all-btn" class="danger-btn">Clear All</button>
        </div>
      </div>

      <div style="overflow:auto;">
        <table class="stocks-table">
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Category</th>
              <th>Price</th>
              <th>Qty</th>
              <th>Image</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="stocks-tbody"></tbody>
        </table>
      </div>
    </div>
  </section>
</main>

<footer class="footer section">
  <div class="container" style="text-align:center; padding:1rem 0;">
    <p style="color:var(--text-color-light); font-size:.9rem;">&copy; 2025 Lagro Bistro. All rights reserved.</p>
  </div>
</footer>

<!--=============== ADD / EDIT MODAL ===============-->
<div id="modal-root" style="display:none;">
  <div class="modal-overlay" id="modal-overlay">
    <div class="modal">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:.5rem;">
        <h3 id="modal-title">Add Item</h3>
        <button id="modal-close" class="button" style="background:transparent; border:1px solid var(--border-color);">Close</button>
      </div>

      <form id="item-form">
        <label>Product Name
          <input type="text" id="prod-name" required>
        </label>
        <br>
        <label for="prod-category">Category</label>
        <input list="category-list" id="prod-category" name="prod-category" placeholder="e.g. Coffee, Pastries" required>
        <datalist id="category-list">
          <option value="Coffee">
          <option value="Non-Coffee">
          <option value="Pastries">
          <option value="Sandwiches">
          <option value="Others">
        </datalist>

        <div class="form-row">
          <div class="col">
            <label>Price (₱)
              <input type="number" id="prod-price" min="0" step="0.01" required>
            </label>
          </div>
          <div class="col">
            <label>Quantity
              <input type="number" id="prod-qty" min="0" step="1" required>
            </label>
          </div>
        </div>

        <label>Image URL
          <input type="text" id="prod-img" placeholder="e.g. assets/img/product.jpg">
        </label>
        <label>
          <input type="checkbox" id="prod-featured"> Mark as Best Seller
        </label>

        <div style="display:flex; justify-content:flex-end; gap:.5rem;">
          <button type="button" id="cancel-btn" class="button" style="background:transparent; border:1px solid var(--border-color);">Cancel</button>
          <button type="submit" class="button">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="assets/js/swiper-bundle.min.js"></script>
<script src="assets/js/main.js"></script>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const tbody = document.getElementById("stocks-tbody");
  const addBtn = document.getElementById("add-item-btn");
  const clearBtn = document.getElementById("clear-all-btn");
  const modalRoot = document.getElementById("modal-root");
  const modalOverlay = document.getElementById("modal-overlay");
  const modalClose = document.getElementById("modal-close");
  const cancelBtn = document.getElementById("cancel-btn");
  const form = document.getElementById("item-form");
  const searchInput = document.getElementById("search-input");
  const modalTitle = document.getElementById("modal-title");

  const nameInput = document.getElementById("prod-name");
  const catInput  = document.getElementById("prod-category");
  const priceInput= document.getElementById("prod-price");
  const qtyInput  = document.getElementById("prod-qty");
  const imgInput  = document.getElementById("prod-img");
  const featuredInput = document.getElementById("prod-featured");

  let editingIndex = null;

  const loadStocks = () => JSON.parse(localStorage.getItem("stocks")) || [];
  const saveStocks = (arr) => localStorage.setItem("stocks", JSON.stringify(arr));

  const formatPrice = n => "₱" + parseFloat(n).toLocaleString(undefined,{ minimumFractionDigits:2 });
  const getStatus = qty => qty === 0 ? {text:"Out of stock",cls:"status-out"} : qty<=10 ? {text:"Low",cls:"status-low"} : {text:"In stock",cls:"status-in"};

  const escapeHtml = txt => String(txt || "").replace(/[&<>\"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "\"":"&quot;", "'":"&#039;" }[c]));

  function updateCategoryList() {
    const stocks = loadStocks();
    const existingCategories = [...new Set(stocks.map(s => s.category).filter(Boolean))];
    const defaultCategories = ["Coffee", "Non-Coffee", "Pastries", "Sandwiches", "Others"];
    const allCategories = Array.from(new Set([...defaultCategories, ...existingCategories])).sort();
    const categoryList = document.getElementById("category-list");
    if (!categoryList) return;
    categoryList.innerHTML = allCategories.map(c => `<option value="${c}">`).join("");
  }

  function renderTable(filter="") {
    const q = filter.toLowerCase();
    const stocks = loadStocks();
    tbody.innerHTML = "";
    if (!stocks.length) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;">No products available</td></tr>`;
      return;
    }
    stocks.forEach((item, i) => {
      if (q && !item.name.toLowerCase().includes(q) && !item.category.toLowerCase().includes(q)) return;
      const st = getStatus(item.qty);
      tbody.insertAdjacentHTML("beforeend", `
        <tr>
          <td>${escapeHtml(item.name)} ${item.featured ? "<span style='color:#f59e0b;font-weight:600;'>⭐</span>" : ""}</td>
          <td>${escapeHtml(item.category)}</td>
          <td>${formatPrice(item.price)}</td>
          <td>${item.qty}</td>
          <td>${item.image ? `<img src="${item.image}" style="width:45px;height:45px;border-radius:.5rem;">` : "—"}</td>
          <td><span class="status-badge ${st.cls}">${st.text}</span></td>
          <td>
            <button class="button action-btn" data-edit="${i}"><i class='bx bx-edit'></i></button>
            <button class="button action-btn" data-delete="${i}" style="background:transparent;border:1px solid var(--border-color);"><i class='bx bx-trash'></i></button>
          </td>
        </tr>
      `);
    });
  }

  addBtn.onclick = () => {
    editingIndex = null;
    modalTitle.textContent = "Add Item";
    form.reset();
    updateCategoryList();
    modalRoot.style.display = "block";
  };

  modalClose.onclick = () => modalRoot.style.display = "none";
  cancelBtn.onclick = () => modalRoot.style.display = "none";
  modalOverlay.onclick = e => { if (e.target === modalOverlay) modalRoot.style.display = "none"; };

  tbody.onclick = e => {
    const editBtn = e.target.closest("[data-edit]");
    const delBtn = e.target.closest("[data-delete]");
    const stocks = loadStocks();
    if (editBtn) {
      const i = editBtn.dataset.edit;
      editingIndex = i;
      const it = stocks[i];
      nameInput.value = it.name;
      catInput.value = it.category;
      priceInput.value = it.price;
      qtyInput.value = it.qty;
      imgInput.value = it.image;
      featuredInput.checked = it.featured || false; // ✅ keep featured toggle synced
      modalTitle.textContent = "Edit Item";
      updateCategoryList();
      modalRoot.style.display = "block";
    }
    if (delBtn) {
      const i = delBtn.dataset.delete;
      if (confirm("Delete this item?")) {
        stocks.splice(i, 1);
        saveStocks(stocks);
        renderTable(searchInput.value);
      }
    }
  };

  form.onsubmit = e => {
    e.preventDefault();
    const name = nameInput.value.trim();
    const category = catInput.value.trim();
    const price = parseFloat(priceInput.value);
    const qty = parseInt(qtyInput.value);
    const image = imgInput.value.trim() || "assets/img/default.png";
    const featured = featuredInput.checked;
    if (!name || !category || isNaN(price) || isNaN(qty)) return alert("Please fill in all fields.");

    const stocks = loadStocks();
    const data = {
      id: editingIndex !== null && stocks[editingIndex]?.id 
            ? stocks[editingIndex].id 
            : Date.now().toString(),
      name,
      category,
      price,
      qty,
      image,
      featured
    };
    if (editingIndex !== null) stocks[editingIndex] = data;
    else stocks.push(data);

    saveStocks(stocks);
    modalRoot.style.display = "none";
    renderTable(searchInput.value);
  };

  clearBtn.onclick = () => {
    if (confirm("Clear all items?")) {
      localStorage.removeItem("stocks");
      renderTable();
      updateCategoryList();
    }
  };

  searchInput.oninput = () => renderTable(searchInput.value);

  updateCategoryList();
  renderTable();
});
</script>
</body>
</html>
