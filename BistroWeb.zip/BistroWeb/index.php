<?php
session_start();
include 'db_connect.php';

// Basic login protection
if (!isset($_SESSION['username'])) {
  header("Location: login.html");
  exit();
}

// 🛑 Check if user is banned
$username = $_SESSION['username'];
$check = mysqli_query($conn, "SELECT status FROM users WHERE username='$username'");
$user = mysqli_fetch_assoc($check);

if (isset($user['status']) && strtolower($user['status']) === 'banned') {
  session_destroy();
  echo "<script>
          alert('Your account has been banned. Please contact the administrator.');
          window.location.href='login.html';
        </script>";
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">
  <title>Lagro Bistro</title>
  <style>
        /* ===== CHECKOUT FORM SHARED STYLES ===== */
    .checkout-box {
      background: var(--container-color);
      border-radius: 1rem;
      padding: 1.5rem;
      box-shadow: 0 20px 40px rgba(0,0,0,.15);
    }

    .checkout-box .label {
      font-weight: 600;
      margin-bottom: .5rem;
      display: block;
    }

    /* ===== PAYMENT OPTIONS ===== */
    .payment-section,
    .notes-section {
      background: var(--body-color);
      border: 1px solid var(--border-color);
      border-radius: .75rem;
      padding: 1rem;
      margin-bottom: 1rem;
    }

    .pay-option {
      display: flex;
      align-items: center;
      gap: .6rem;
      padding: .6rem .75rem;
      border-radius: .5rem;
      cursor: pointer;
      transition: background .2s ease;
    }

    .pay-option:hover {
      background: rgba(0,0,0,.04);
    }

    .pay-option input {
      accent-color: var(--first-color);
    }

    /* ===== NOTES ===== */
    .notes-section textarea {
      width: 100%;
      min-height: 90px;
      resize: vertical;
      padding: .65rem;
      border-radius: .5rem;
      border: 1px solid var(--border-color);
      font-family: inherit;
      font-size: .95rem;
    }

    .notes-section textarea:focus {
      outline: none;
      border-color: var(--first-color);
    }

    /* ===== ACTION BUTTONS ===== */
    .checkout-actions {
      display: flex;
      gap: .75rem;
      justify-content: flex-end;
    }

    #bg-video {
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      object-fit: cover;
      z-index: -1;
      opacity: 0.25;
      filter: blur(2px) brightness(0.7);
    }
    .out-of-stock { color: #f87171; font-weight: 600; }
    .low-stock { color: #facc15; font-weight: 600; }
    .in-stock { color: #4ade80; font-weight: 600; }
    .stock-label { margin-top: 5px; font-size: 0.9rem; }

    .home__img-bg img {
      height: 100%;
      margin-bottom: 10px;
    }
    .cart__notes {
  margin: .75rem 0;
}

.cart__notes label {
  display: block;
  font-size: .85rem;
  margin-bottom: .35rem;
  color: var(--text-color-light);
}

.cart__notes textarea {
  width: 100%;
  resize: none;
  padding: .5rem .6rem;
  border-radius: .4rem;
  border: 1px solid var(--border-color);
  background: var(--container-color);
  color: var(--text-color);
  font-size: .85rem;
}

  </style>
</head>
<body>
<video autoplay muted loop playsinline id="bg-video">
  <source src="bistro2.mp4" type="video/mp4">
</video>

<!--=============== HEADER ===============-->
<header class="header" id="header">
  <nav class="nav container">
    <a href="index.php" class="nav__logo">
      <img src="photos/487406000_1540026813360052_5463353511999549857_n (1).png" class="logo" alt="">
      Lagro Bistro
    </a>
    <div class="nav__menu" id="nav-menu">
      <ul class="nav__list">
        <li class="nav__item"><a href="index.php" class="nav__link active-link">Home</a></li>
        <li class="nav__item"><a href="menu.php" class="nav__link">Menu</a></li>
        <li class="nav__item"><a href="orderhistory.php" class="nav__link">Order History</a></li>
        <?php if ($_SESSION['role'] === 'admin'): ?>
          <li class="nav__item"><a href="stocks.php" class="nav__link">Stocks</a></li>
        <?php endif; ?>
        <li class="nav__item"><a href="logout.php" class="nav__link">Logout</a></li>
      </ul>
      <div class="nav__close" id="nav-close"><i class='bx bx-x'></i></div>
    </div>
    <div class="nav__btns">
      <i class='bx bx-moon change-theme' id="theme-button"></i>
      <div class="nav__shop" id="cart-button" title="My Cart">
        <i class='bx bx-shopping-bag'></i>
      </div>
      <div class="nav__toggle" id="nav-toggle"><i class='bx bx-grid-alt'></i></div>
    </div>
  </nav>
</header>

<!--=============== CART ===============-->
<div class="cart" id="cart">
  <i class='bx bx-x cart__close' id="cart-close"></i>
  <h2 class="cart__title-center">My Cart</h2>
  <div class="cart__container"></div>
  <div class="cart__prices">
    <span class="cart__prices-item">Total</span>
    <span class="cart__prices-total">₱0</span>
  </div>
  <div style="margin:15px;text-align:center;">
  <label for="payment_method"><strong>Payment Method</strong></label><br>
  <select id="payment_method" style="padding:6px;width:80%;margin-top:5px;">
    <option value="">-- Select Payment --</option>
    <option value="Cash on Delivery">Cash on Delivery</option>
    <option value="GCash">GCash</option>
    <option value="Card">Card</option>
  </select>
</div>
<div class="cart__notes">
  <label for="order-notes">Notes for staff</label>
  <textarea
    id="order-notes"
    placeholder="e.g. No sugar, extra hot, no ice, etc."
    rows="3"></textarea>
</div>
  <div align="center">
    <button id="checkout-btn" class="Checkout">Check out</button>
  </div>
</div>

<!--=============== MAIN CONTENT ===============-->
<main class="main">
  <section class="home" id="home">
    <div class="home__container container grid">
      <div class="home__img-bg">
        <img src="photos/DSC_0225.png" alt="" class="home__img">
      </div>
      <div class="home__data">
        <h1 class="home__title">WELCOME TO <br> THE BISTRO WEBSITE</h1>
        <p class="home__description">Enjoy our best coffee and treats — freshly made every day!</p>
        <div class="home__btns">
          <a href="#products" class="button button--gray button--small">Discover</a>
        </div>
      </div>
    </div>
  </section>

  <!--=============== BEST SELLERS SECTION ===============-->
  <section class="products section container" id="products">
    <h2 class="section__title">Best Sellers</h2>
    <div class="products__container grid" id="products-container"></div>
  </section>
</main>

<!--=============== FOOTER ===============-->
<footer class="footer section">
  <div class="footer__container container grid">
    <div class="footer__content">
      <h3 class="footer__title">Our Information</h3>
      <ul class="footer__list">
        <li>Lagro, Quezon City</li>
        <li>Contact: 123-456-789</li>
      </ul>
    </div>
    <div class="footer__content">
      <h3 class="footer__title">Social</h3>
      <ul class="footer__social">
        <a href="https://www.facebook.com/" target="_blank" class="footer__social-link"><i class='bx bxl-facebook'></i></a>
        <a href="https://twitter.com/" target="_blank" class="footer__social-link"><i class='bx bxl-twitter'></i></a>
        <a href="https://www.instagram.com/" target="_blank" class="footer__social-link"><i class='bx bxl-instagram'></i></a>
      </ul>
    </div>
  </div>
  <span class="footer__copy">&#169; 2025 Lagro Bistro</span>
</footer>

<a href="#" class="scrollup" id="scroll-up"><i class='bx bx-up-arrow-alt scrollup__icon'></i></a>

<script src="assets/js/swiper-bundle.min.js"></script>
<script src="assets/js/main.js"></script>

<!--=============== PRODUCT & CART LOGIC ===============-->
<script>

document.addEventListener("DOMContentLoaded", () => {
  
  const container = document.getElementById("products-container");
  const cartContainer = document.querySelector(".cart__container");
  const totalDisplay = document.querySelector(".cart__prices-total");
  const checkoutBtn = document.getElementById("checkout-btn");

  const cartBtn = document.getElementById("cart-button");
  const cart = document.getElementById("cart");
  const cartClose = document.getElementById("cart-close");

  // ✅ CART OPEN/CLOSE FIX
  cartBtn?.addEventListener("click", () => cart.classList.add("show-cart"));
  cartClose?.addEventListener("click", () => cart.classList.remove("show-cart"));

  // ✅ load products (from localStorage stocks)
  const defaultStocks = [
    { id: 1, name: "Classic Coffee", price: 45, qty: 15, image: "assets/img/product1.png", featured: true },
    { id: 2, name: "Ham & Cheese Sandwich", price: 95, qty: 8, image: "assets/img/product2.png", featured: false },
    { id: 3, name: "Chocolate Cake Slice", price: 75, qty: 3, image: "assets/img/product3.png", featured: true }
  ];
  let stocks = JSON.parse(localStorage.getItem("stocks") || "null") || defaultStocks;
  let cartData = JSON.parse(localStorage.getItem("cart") || "[]");

  const bestSellers = stocks.filter(item => item.featured);

  function saveCart() { localStorage.setItem("cart", JSON.stringify(cartData)); }

  function renderProducts() {
    container.innerHTML = "";
    if (bestSellers.length === 0) {
      container.innerHTML = `<p style="text-align:center;color:var(--text-color-light);">No best sellers yet. Please check back later!</p>`;
      return;
    }

    bestSellers.forEach(product => {
      const disabled = product.qty <= 0 ? "disabled" : "";
      const stockStatus = product.qty <= 0 ? `<span class='out-of-stock'>Out of Stock</span>`
        : product.qty <= 3 ? `<span class='low-stock'>Low Stock</span>`
        : `<span class='in-stock'>In Stock</span>`;

      container.insertAdjacentHTML("beforeend", `
        <article class="products__card" data-id="${product.id}">
          <img src="${product.image}" alt="${product.name}" class="products__img">
          <h3 class="products__title">${product.name} ⭐</h3>
          <span class="products__price">₱${product.price}</span>
          <p class="stock-label">${stockStatus} — ${product.qty} left</p>
          <button class="products__button" data-id="${product.id}" ${disabled}>
            ${disabled ? "Out of Stock" : "Add to Cart"}
          </button>
        </article>
      `);
    });
  }

  function renderCart() {
    cartContainer.innerHTML = "";
    let total = 0;
    cartData.forEach((item, index) => {
      total += item.price * item.qty;
      cartContainer.insertAdjacentHTML("beforeend", `
        <div class="cart__card">
          <img src="${item.image}" alt="${item.name}" class="cart__img">
          <div class="cart__details">
            <h3 class="cart__title">${item.name}</h3>
            <span class="cart__price">₱${item.price}</span>
            <div class="cart__amount">
              <div class="cart__amount-content">
                <button class="cart__amount-box cart-decr" data-index="${index}">-</button>
                <span class="cart__amount-number">${item.qty}</span>
                <button class="cart__amount-box cart-incr" data-index="${index}">+</button>
              </div>
              <i class='bx bx-trash-alt cart__amount-trash' data-index="${index}"></i>
            </div>
          </div>
        </div>
      `);
    });
    totalDisplay.textContent = `₱${total.toFixed(2)}`;
  }

  // ✅ Add to Cart
  container.addEventListener("click", e => {
    const btn = e.target.closest(".products__button");
    if (!btn) return;
    const id = btn.dataset.id;
    const product = stocks.find(p => String(p.id) === String(id));
    if (!product || product.qty <= 0) return alert("Out of stock!");
    const existing = cartData.find(c => String(c.id) === String(id));
    if (existing) existing.qty++;
    else cartData.push({ ...product, qty: 1 });
    product.qty--;
    localStorage.setItem("stocks", JSON.stringify(stocks));
    saveCart();
    renderProducts();
    renderCart();
  });

  // ✅ Cart increment/decrement/remove
  cartContainer.addEventListener("click", e => {
    const incr = e.target.closest(".cart-incr");
    const decr = e.target.closest(".cart-decr");
    const trash = e.target.closest(".cart__amount-trash");

    if (incr) {
      const idx = +incr.dataset.index;
      const item = cartData[idx];
      const stock = stocks.find(p => p.id == item.id);
      if (stock.qty <= 0) return alert("No more stock!");
      item.qty++; stock.qty--;
    }

    if (decr) {
      const idx = +decr.dataset.index;
      const item = cartData[idx];
      const stock = stocks.find(p => p.id == item.id);
      item.qty--; stock.qty++;
      if (item.qty <= 0) cartData.splice(idx, 1);
    }

    if (trash) {
      const idx = +trash.dataset.index;
      const item = cartData[idx];
      const stock = stocks.find(p => p.id == item.id);
      stock.qty += item.qty;
      cartData.splice(idx, 1);
    }

    localStorage.setItem("stocks", JSON.stringify(stocks));
    saveCart();
    renderProducts();
    renderCart();
  });

  // ✅ Checkout — saves order to backend (PHP)
checkoutBtn.addEventListener("click", async () => {
  if (cartData.length === 0) return alert("Your cart is empty!");

  const paymentMethod = document.getElementById("payment_method").value;
  if (!paymentMethod) return alert("Please select a payment method!");

  const orderItems = cartData.map(i => ({
    name: i.name,
    price: i.price,
    qty: i.qty
  }));

  const notesInput = document.getElementById("order-notes");
  const notes = notesInput ? notesInput.value.trim() : "";

  const total = cartData.reduce((sum, i) => sum + i.price * i.qty, 0);

  try {
    const res = await fetch("save_order.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
      items: orderItems,
      total,
      payment_method: paymentMethod,
      notes
      })
    });

    const data = await res.json();
if (data.success) {
  alert("Order placed successfully!");

  // HARD clear cart
  cartData.length = 0;
  localStorage.setItem("cart", "[]");

  // Reset UI
  renderCart();

  // Close cart UI
  cart.classList.remove("show-cart");

  // Delay redirect to guarantee commit
  setTimeout(() => {
    window.location.href = "orderhistory.php";
  }, 150);
}
 else {
  alert("Error saving order");
}
  } catch (err) {
    
  }
});


  renderProducts();
  renderCart();
});


</script>
</body>
</html>
