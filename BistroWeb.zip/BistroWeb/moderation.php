<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.html");
  exit();
}

$result = mysqli_query($conn, "SELECT * FROM users ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Moderation | Lagro Bistro</title>

  <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">

  <style>
    body {
      background: var(--body-color);
      color: var(--text-color);
      font-family: var(--body-font);
    }

    main {
      margin-top: 6rem;
      padding: 2rem;
    }

    h2.section__title {
      text-align: center;
      color: var(--title-color);
      margin-bottom: 1.5rem;
    }

    .filter-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 1rem;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }

    .filter-bar input,
    .filter-bar select {
      padding: .6rem .8rem;
      border: 1px solid var(--border-color);
      border-radius: .5rem;
      background: var(--container-color);
      color: var(--text-color);
      width: 180px;
    }

    .table-container {
      overflow-x: auto;
      background: var(--container-color);
      border-radius: 1rem;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      padding: 1.5rem;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
    }

    th, td {
      padding: 1rem;
      border-bottom: 1px solid var(--border-color-light);
    }

    th {
      background: var(--first-color);
      color: #fff;
      text-transform: uppercase;
      font-size: .9rem;
      letter-spacing: .05rem;
    }

    tr:hover {
      background: var(--first-color-lighten);
      transition: 0.2s;
    }

    .btn {
      padding: .4rem .8rem;
      border: none;
      border-radius: .5rem;
      cursor: pointer;
      font-size: .85rem;
      transition: background 0.2s;
    }

    .btn-edit { background: var(--first-color); color: #fff; }
    .btn-edit:hover { background: var(--first-color-alt); }
    .btn-ban { background: #ef4444; color: #fff; }
    .btn-ban:hover { background: #dc2626; }
    .btn-unban { background: #10b981; color: #fff; }
    .btn-unban:hover { background: #059669; }

    .modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.5);
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: var(--container-color);
      padding: 2rem;
      border-radius: 1rem;
      width: 400px;
      max-width: 90%;
      box-shadow: 0 4px 20px rgba(0,0,0,0.25);
    }

    .modal-content h3 {
      margin-bottom: 1rem;
      color: var(--title-color);
    }

    .modal-content input,
    .modal-content select {
      width: 100%;
      padding: .75rem;
      border: 1px solid var(--border-color);
      border-radius: .5rem;
      background: var(--input-color);
      color: var(--text-color);
      margin-bottom: 1rem;
    }

    .modal-close {
      float: right;
      font-size: 1.5rem;
      cursor: pointer;
      color: var(--title-color);
    }

    @media (max-width: 768px) {
      th, td { padding: .75rem; font-size: .85rem; }
      .modal-content { width: 90%; }
      .filter-bar { flex-direction: column; align-items: stretch; }
      .filter-bar input, .filter-bar select { width: 100%; }
    }
  </style>
</head>

<body>

  <!-- Header -->
  <header class="header" id="header">
    <nav class="nav container">
      <a href="index.php" class="nav__logo">
        <img src="photos/487406000_1540026813360052_5463353511999549857_n (1).png" class="logo" alt="">
        Lagro Bistro
      </a>

      <div class="nav__menu" id="nav-menu">
        <ul class="nav__list">
          <li class="nav__item"><a href="index.php" class="nav__link">Home</a></li>
          <li class="nav__item"><a href="menu.php" class="nav__link">Menu</a></li>
          <li class="nav__item"><a href="orderhistory.php" class="nav__link">Order History</a></li>
          <li class="nav__item"><a href="stocks.php" class="nav__link">Stocks</a></li>
          <li class="nav__item"><a href="moderation.php" class="nav__link active-link">Moderation</a></li>
          <li class="nav__item"><a href="logout.php" class="nav__link">Logout</a></li>
        </ul>
        <div class="nav__close" id="nav-close"><i class='bx bx-x'></i></div>
      </div>

      <div class="nav__btns">
        <i class='bx bx-moon change-theme' id="theme-button"></i>
        <div class="nav__toggle" id="nav-toggle"><i class='bx bx-grid-alt'></i></div>
      </div>
    </nav>
  </header>

  <!-- Content -->
  <main class="main">
    <section class="container section">
      <h2 class="section__title">User Moderation Panel</h2>

      <!-- 🔍 Search & Filters -->
      <div class="filter-bar">
        <input type="text" id="search" placeholder="Search by username...">
        <select id="filter-role">
          <option value="">All Roles</option>
          <option value="admin">Admin</option>
          <option value="customer">Customer</option>
        </select>
        <select id="filter-status">
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="banned">Banned</option>
        </select>
      </div>

      <div class="table-container">
        <table id="userTable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>LRN</th>
              <th>Grade</th>
              <th>Section</th>
              <th>Role</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
              <tr data-id="<?= $row['id'] ?>" 
                  data-username="<?= htmlspecialchars($row['username']) ?>" 
                  data-lrn="<?= htmlspecialchars($row['lrn']) ?>" 
                  data-grade="<?= htmlspecialchars($row['grade']) ?>" 
                  data-section="<?= htmlspecialchars($row['section']) ?>" 
                  data-role="<?= htmlspecialchars($row['role']) ?>" 
                  data-status="<?= htmlspecialchars($row['status'] ?? 'active') ?>">
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td><?= htmlspecialchars($row['lrn']) ?></td>
                <td><?= htmlspecialchars($row['grade']) ?></td>
                <td><?= htmlspecialchars($row['section']) ?></td>
                <td><?= htmlspecialchars($row['role']) ?></td>
                <td><?= htmlspecialchars($row['status'] ?? 'active') ?></td>
                <td>
                  <button class="btn btn-edit">Edit</button>
                  <?php if (($row['status'] ?? 'active') === 'banned'): ?>
                    <button class="btn btn-unban">Unban</button>
                  <?php else: ?>
                    <button class="btn btn-ban">Ban</button>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </section>
  </main>

  <!-- Modal -->
  <div class="modal" id="editModal">
    <div class="modal-content">
      <span class="modal-close" id="closeModal">&times;</span>
      <h3>Edit User</h3>
      <form id="editForm">
        <input type="hidden" name="id" id="edit-id">
        <label>Username</label>
        <input type="text" name="username" id="edit-username" required>
        <label>LRN</label>
        <input type="text" name="lrn" id="edit-lrn">
        <label>Grade</label>
        <input type="text" name="grade" id="edit-grade">
        <label>Section</label>
        <input type="text" name="section" id="edit-section">
        <label>Role</label>
        <select name="role" id="edit-role">
          <option value="customer">Customer</option>
          <option value="admin">Admin</option>
        </select>
        <button type="submit" class="btn btn-edit" style="width:100%;margin-top:.5rem;">Save Changes</button>
      </form>
    </div>
  </div>

  <a href="#" class="scrollup" id="scroll-up"><i class='bx bx-up-arrow-alt scrollup__icon'></i></a>

  <script src="assets/js/swiper-bundle.min.js"></script>
  <script src="assets/js/main.js"></script>

  <script>
    const modal = document.getElementById("editModal");
    const closeModal = document.getElementById("closeModal");
    const form = document.getElementById("editForm");
    const searchInput = document.getElementById("search");
    const filterRole = document.getElementById("filter-role");
    const filterStatus = document.getElementById("filter-status");

    // Open modal for edit
    document.querySelectorAll(".btn-edit").forEach(btn => {
      btn.addEventListener("click", e => {
        const row = e.target.closest("tr");
        document.getElementById("edit-id").value = row.dataset.id;
        document.getElementById("edit-username").value = row.dataset.username;
        document.getElementById("edit-lrn").value = row.dataset.lrn;
        document.getElementById("edit-grade").value = row.dataset.grade;
        document.getElementById("edit-section").value = row.dataset.section;
        document.getElementById("edit-role").value = row.dataset.role;
        modal.style.display = "flex";
      });
    });

    closeModal.addEventListener("click", () => modal.style.display = "none");

    // Submit edit form
    form.addEventListener("submit", async e => {
      e.preventDefault();
      const res = await fetch("update_user.php", { method: "POST", body: new FormData(form) });
      const data = await res.json();
      alert(data.message);
      if (data.success) location.reload();
    });

    // Ban / Unban
    document.querySelectorAll(".btn-ban, .btn-unban").forEach(btn => {
      btn.addEventListener("click", async e => {
        const row = e.target.closest("tr");
        const id = row.dataset.id;
        const action = btn.classList.contains("btn-ban") ? "ban" : "unban";
        const res = await fetch("user_status.php", {
          method: "POST",
          headers: {"Content-Type": "application/x-www-form-urlencoded"},
          body: `id=${id}&action=${action}`
        });
        const data = await res.json();
        alert(data.message);
        if (data.success) location.reload();
      });
    });

    // Search & Filter
    const table = document.getElementById("userTable").getElementsByTagName("tbody")[0];
    function applyFilters() {
      const searchVal = searchInput.value.toLowerCase();
      const roleVal = filterRole.value.toLowerCase();
      const statusVal = filterStatus.value.toLowerCase();

      Array.from(table.rows).forEach(row => {
        const username = row.cells[1].textContent.toLowerCase();
        const role = row.cells[5].textContent.toLowerCase();
        const status = row.cells[6].textContent.toLowerCase();
        const matches = 
          (!searchVal || username.includes(searchVal)) &&
          (!roleVal || role === roleVal) &&
          (!statusVal || status === statusVal);
        row.style.display = matches ? "" : "none";
      });
    }
    searchInput.addEventListener("input", applyFilters);
    filterRole.addEventListener("change", applyFilters);
    filterStatus.addEventListener("change", applyFilters);
  </script>

</body>
</html>
